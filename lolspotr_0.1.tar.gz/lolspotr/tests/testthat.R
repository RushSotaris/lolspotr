library(testthat)
library(lolspotr)

test_check("lolspotr")
